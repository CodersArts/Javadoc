package assn1;
/**
 * @author 
 * Date 18-AUG-2018
 * This is date class having month and day.
 *
 */
public class Date {
	private String month;
	private int day;

	/**
	 * @param month
	 * @param day
	 */
	public Date(String month, int day) {
		this.month = month;
		this.day = day;
	}

	/**
	 * @param date
	 * @return
	 */
	public boolean equals(Date date) {
		return (month.equalsIgnoreCase(month)) && (day == day);
	}

	/**
	 * @return
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * @return
	 */
	public int getDay() {
		return day;
	}
}