package assn1;

/**
 * @author 
 * Date 18-AUG-2018
 * This class is used for booking of single,double,triple room as per request.
 * This is driver(main) class of hotel booking system.
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HotelBookingSystem {
	private List<Hotel> hotels;
	private List<Booking> bookings;

	/**
	 * 
	 */
	public HotelBookingSystem() {
		hotels = new ArrayList();
		bookings = new ArrayList();
	}

	/**
	 * @param hotelName
	 * @return
	 * To get the Hotel occupancy.
	 */
	public String getHotelOccupancy(String hotelName) {
		Hotel hotel = findHotel(hotelName);

		if (hotel != null) {
			return hotel.getOccupancy(hotelName);
		}

		return "";
	}

	/**
	 * @param id
	 * @return
	 * To get the hotel and following room in that hotel as per request.
	 */
	public String getHotelsAndRoomsOfBooking(String id) {
		String string = "";

		for (Hotel hotel : hotels) {
			List<Room> rooms = hotel.getRoomsOfBooking(id);

			if (!rooms.isEmpty()) {
				string = string + hotel.getName() + " ";

				for (Room room : rooms) {
					string = string + room.getNumber() + " ";
				}
			}
		}

		return string;
	}

	/**
	 * @param name
	 * @return
	 * This method is used to find the Hotel.
	 */
	public Hotel findHotel(String name) {
		for (Hotel hotel : hotels) {
			if (hotel.getName().equalsIgnoreCase(name)) {
				return hotel;
			}
		}

		return null;
	}

	/**
	 * @param id
	 * @return
	 */
	public Booking getBooking(String id) {
		for (Booking booking : bookings) {
			if (booking.getID().equals(id)) {
				return booking;
			}
		}

		return null;
	}

	/**
	 * @param hotel
	 * @return
	 * This is used to add hotel in hotels list.
	 */
	public boolean addHotel(Hotel hotel) {
		if (findHotel(hotel.getName()) != null) {
			return false;
		}

		hotels.add(hotel);
		return true;
	}

	/**
	 * @param booking
	 * @return
	 * This method is used for accepting the bookings.
	 */
	public boolean acceptBooking(Booking booking) {
		bookings.add(booking);

		if ((countTotalAvailableRooms(1) >= booking.getSingleRoomsNeeded())
				&& (countTotalAvailableRooms(2) >= booking.getDoubleRoomsNeeded())
				&& (countTotalAvailableRooms(3) >= booking.getTripleRoomsNeeded())) {

			for (int i = 0; i < booking.getSingleRoomsNeeded(); i++) {
				Room room = findNextAvailableRoom(1);
				room.assignBooking(booking);
			}

			for (int i = 0; i < booking.getDoubleRoomsNeeded(); i++) {
				Room room = findNextAvailableRoom(2);
				room.assignBooking(booking);
			}

			for (int i = 0; i < booking.getTripleRoomsNeeded(); i++) {
				Room room = findNextAvailableRoom(3);
				room.assignBooking(booking);
			}

			booking.setFulfilled(true);
			return true;
		}
		booking.setFulfilled(false);
		return false;
	}

	/**
	 * @param booking
	 * @return
	 * This method is used for Updating booking as per request.
	 */
	public boolean updateBooking(Booking booking) {
		if (!cancelBooking(booking.getID())) {
			return false;
		}

		return acceptBooking(booking);
	}

	/**
	 * @param bookingName
	 * @return
	 */
	public boolean cancelBooking(String bookingName) {
		Booking booking = getBooking(bookingName);

		if (booking == null) {
			return false;
		}

		for (Hotel hotel : hotels) {
			hotel.removeBooking(bookingName);
		}

		bookings.remove(booking);
		return true;
	}

	/**
	 * @param capacity
	 * @return
	 * This method is used to find the available rooms in hostel
	 */
	public Room findNextAvailableRoom(int capacity) {
		for (Hotel hotel : hotels) {
			Room room = hotel.findNextAvailableRoom(capacity);

			if (room != null) {
				return room;
			}
		}

		return null;
	}

	/**
	 * @param capacity
	 * @return
	 */
	public int countTotalAvailableRooms(int capacity) {
		int total = 0;

		for (Hotel hotel : hotels) {
			total += hotel.countAvailableRooms(capacity);
		}

		return total;
	}

	/**
	 * @param args
	 * This is main method to drive the hotels booking.
	 */
	public static void main(String[] args) {
		HotelBookingSystem system = new HotelBookingSystem();
		Scanner sc = null;

		String line = "";
		try {
			sc = new Scanner(new File(args[0]));

			while (sc.hasNextLine()) {
				line = sc.nextLine();
				String[] tokens = line.split(" ");
				String command = tokens[0];

				if ((command.equalsIgnoreCase("HOTEL")) && (tokens.length == 4)) {
					String hotelName = tokens[1];
					int roomNumber = Integer.parseInt(tokens[2]);
					int capacity = Integer.parseInt(tokens[3]);

					Hotel hotel = system.findHotel(hotelName);

					if (hotel == null) {
						hotel = new Hotel(hotelName);
						system.addHotel(hotel);
					}

					hotel.addRoom(new Room(roomNumber, capacity));
				} else if ((command.equalsIgnoreCase("BOOKING")) && (tokens.length >= 7)) {
					String bookingName = tokens[1];
					String month = tokens[2];
					int day = Integer.parseInt(tokens[3]);
					int numDays = Integer.parseInt(tokens[4]);

					int singleRoomsNeeded = 0;
					int doubleRoomsNeeded = 0;
					int tripleRoomsNeeded = 0;

					for (int i = 5; i < tokens.length; i += 2) {
						String roomType = tokens[i];

						if (roomType.equalsIgnoreCase("SINGLE")) {
							singleRoomsNeeded += Integer.parseInt(tokens[(i + 1)]);
						} else if (roomType.equalsIgnoreCase("DOUBLE")) {
							doubleRoomsNeeded += Integer.parseInt(tokens[(i + 1)]);
						} else if (roomType.equalsIgnoreCase("TRIPLE")) {
							tripleRoomsNeeded += Integer.parseInt(tokens[(i + 1)]);
						} else {
							throw new Exception("Invalid room type");
						}
					}

					if (system.acceptBooking(new Booking(bookingName, new Date(month, day), numDays, singleRoomsNeeded,
							doubleRoomsNeeded, tripleRoomsNeeded))) {
						System.out.println(
								"Booking " + bookingName + " " + system.getHotelsAndRoomsOfBooking(bookingName));
					} else {
						System.out.println("Booking rejected");
					}
				} else if ((command.equalsIgnoreCase("CHANGE")) && (tokens.length >= 7)) {

					String bookingName = tokens[1];
					String month = tokens[2];
					int day = Integer.parseInt(tokens[3]);
					int numDays = Integer.parseInt(tokens[4]);

					int singleRoomsNeeded = 0;
					int doubleRoomsNeeded = 0;
					int tripleRoomsNeeded = 0;
					system.cancelBooking(bookingName);
					for (int i = 5; i < tokens.length; i += 2) {
						String roomType = tokens[i];

						if (roomType.equalsIgnoreCase("SINGLE")) {
							singleRoomsNeeded += Integer.parseInt(tokens[(i + 1)]);
						} else if (roomType.equalsIgnoreCase("DOUBLE")) {
							doubleRoomsNeeded += Integer.parseInt(tokens[(i + 1)]);
						} else if (roomType.equalsIgnoreCase("TRIPLE")) {
							tripleRoomsNeeded += Integer.parseInt(tokens[(i + 1)]);
						} else {
							throw new Exception("Invalid room type");
						}
					}

					if (system.updateBooking(new Booking(bookingName, new Date(month, day), numDays, singleRoomsNeeded,
							doubleRoomsNeeded, tripleRoomsNeeded))) {
						System.out.println(
								"Change " + bookingName + " " + system.getHotelsAndRoomsOfBooking(bookingName));
					} else {
						System.out.println("Change rejected.");
					}
				} else if ((command.equalsIgnoreCase("CANCEL")) && (tokens.length == 2)) {
					String bookingName = tokens[1];

					if (system.cancelBooking(bookingName)) {
						System.out.println("Cancelled " + bookingName);
					} else {
						System.out.println("Cancel rejected");
					}
				} else if ((command.equalsIgnoreCase("PRINT")) && (tokens.length == 2)) {
					String hotelName = tokens[1];
					System.out.println(system.getHotelOccupancy(hotelName));
				}
			}

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if(sc!=null) {
			sc.close();
			}
 
		}
	}
}
