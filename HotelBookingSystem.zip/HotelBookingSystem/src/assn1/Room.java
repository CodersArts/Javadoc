package assn1;
/**
 * @author 
 * Date 18-AUG-2018
 * This class is used for Room information.
 */
public class Room {
	private int number;
	private int capacity;
	private Booking booking;

	/**
	 * @param number
	 * @param capacity
	 */
	public Room(int number, int capacity) {
		this.number = number;
		this.capacity = capacity;
	}

	/**
	 * @return
	 */
	public String getOccupancy() {
		String string = number + " ";

		if (booking != null) {
			Date date = booking.getArrivalDate();
			string = string + date.getMonth() + " " + date.getDay() + " " + booking.getDays() + " ";
		}

		return string;
	}

	/**
	 * @return
	 */
	public int getCapacity() {
		return capacity;
	}

	/**
	 * @return
	 */
	public Booking getBooking() {
		return booking;
	}

	/**
	 * @return
	 */
	public boolean isAvailable() {
		return booking == null;
	}

	public void removeBooking() {
		booking = null;
	}

	/**
	 * @param booking
	 * @return
	 */
	public boolean assignBooking(Booking booking) {
		if (!isAvailable()) {
			return false;
		}

		this.booking = booking;
		return true;
	}

	/**
	 * @return
	 */
	public int getNumber() {
		return number;
	}
}