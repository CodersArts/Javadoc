package assn1;
/**
 * @author 
 * Date 18-AUG-2018
 * This  class is used for Booking single, double and triple room according to customer requirements. 
 *
 */
public class Booking {
	private String custName;
	private int numDays;
	private boolean fulfilled;
	private Date arrivalDate;
	private int tripleRoomsNeeded;
	private int doubleRoomsNeeded;
	private int singleRoomsNeeded;

	/**
	 * @param name
	 * @param arrivalDate
	 * @param numDays
	 * @param singleRoomsNeeded
	 * @param doubleRoomsNeeded
	 */
	public Booking(String name, Date arrivalDate, int numDays, int singleRoomsNeeded, int doubleRoomsNeeded,int tripleRoomsNeeded) {
		this.custName = name;
		this.arrivalDate = arrivalDate;
		this.numDays = numDays;
		
		this.tripleRoomsNeeded = tripleRoomsNeeded;
		this.doubleRoomsNeeded = doubleRoomsNeeded;
		this.singleRoomsNeeded = singleRoomsNeeded;
		fulfilled = false;
	}

	/**
	 * @return
	 */
	public Date getArrivalDate() {
		return arrivalDate;
	}

	/**
	 * @return
	 */
	public String getID() {
		return custName;
	}

	/**
	 * @return
	 */
	public int getSingleRoomsNeeded() {
		return singleRoomsNeeded;
	}

	/**
	 * @return
	 */
	public int getDoubleRoomsNeeded() {
		return doubleRoomsNeeded;
	}

	public int getTripleRoomsNeeded() {
		return tripleRoomsNeeded;
	}

	/**
	 * @param fulfilled
	 */
	public void setFulfilled(boolean fulfilled) {
		this.fulfilled = fulfilled;
	}

	/**
	 * @return
	 */
	public int getDays() {
		return numDays;
	}
}