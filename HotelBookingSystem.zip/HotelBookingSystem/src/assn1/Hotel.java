package assn1;
/**
 * @author 
 * Date 18-AUG-2018
 *
 */
import java.util.ArrayList;
import java.util.List;

/**
 * @author
 * 
 *
 */
public class Hotel {
	private String name;
	private List<Room> rooms;

	/**
	 * @param name
	 */
	public Hotel(String name) {
		this.name = name;
		rooms = new ArrayList();
	}

	/**
	 * @param capacity
	 * @return
	 */
	public int countAvailableRooms(int capacity) {
		int total = 0;

		for (Room room : rooms) {
			if ((room.isAvailable()) && (room.getCapacity() == capacity)) {
				total++;
			}
		}

		return total;
	}

	/**
	 * @param capacity
	 * @return
	 */
	public Room findNextAvailableRoom(int capacity) {
		for (Room room : rooms) {
			if ((room.isAvailable()) && (room.getCapacity() == capacity)) {
				return room;
			}
		}

		return null;
	}

	/**
	 * @param bookingID
	 */
	public void removeBooking(String bookingID) {
		for (Room room : rooms) {
			if ((room.getBooking() != null) && (room.getBooking().getID().equals(bookingID.trim()))) {
				room.removeBooking();
			}
		}
	}

	/**
	 * @param room
	 * @return
	 */
	public boolean addRoom(Room room) {
		if (getRoom(room.getNumber()) != null) {
			return false;
		}

		rooms.add(room);
		return true;
	}

	/**
	 * @param number
	 * @return
	 */
	public Room getRoom(int number) {
		for (Room room : rooms) {
			if (room.getNumber() == number) {
				return room;
			}
		}

		return null;
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param bookingID
	 * @return
	 */
	public List<Room> getRoomsOfBooking(String bookingID) {
		List<Room> roomsFound = new ArrayList();

		for (Room room : rooms) {
			if ((room.getBooking() != null) && (room.getBooking().getID().equals(bookingID))) {
				roomsFound.add(room);
			}
		}

		return roomsFound;
	}

	/**
	 * @param hotelName
	 * @return
	 */
	public String getOccupancy(String hotelName) {
		String string = "";

		for (Room room : rooms) {
			string = string + hotelName + " " + room.getOccupancy() + "\n";
		}

		return string;
	}
}
